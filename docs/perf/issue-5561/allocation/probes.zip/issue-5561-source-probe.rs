// Temporary diagnostic: included inside work_events_ingest for private APIs.
// This file is gitignored and must never be delivered as product source.
pub(crate) fn run_source_memory_probe() -> bool {
    use std::sync::atomic::Ordering as ProbeOrdering;

    let Ok(mode) = std::env::var("GWT_MEMORY_SOURCE_PROBE_MODE") else {
        return false;
    };
    let result = (|| -> Result<serde_json::Value, String> {
        if !matches!(mode.as_str(), "old" | "new") {
            return Err("GWT_MEMORY_SOURCE_PROBE_MODE must be old or new".into());
        }
        let state = PathBuf::from(
            std::env::var("GWT_MEMORY_SOURCE_PROBE_STATE")
                .map_err(|_| "GWT_MEMORY_SOURCE_PROBE_STATE is required")?,
        );
        let target =
            dunce::canonicalize(PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../target"))
                .map_err(|error| error.to_string())?;
        let index = dunce::canonicalize(state.with_extension("").join("index.json"))
            .map_err(|error| format!("copied grouped intake index: {error}"))?;
        if !index.starts_with(&target) {
            return Err("the grouped intake copy must be inside this checkout's target".into());
        }

        let mut store = WorkEventsIntakeStore::open(&state);
        let groups = store.group_names().map(str::to_owned).collect::<Vec<_>>();
        if groups.is_empty() {
            return Err("the grouped intake copy has no source groups".into());
        }
        let indexed_source_count = store.source_count();
        let group_count = groups.len();
        let mut scanned_source_count = 0usize;
        let mut old_scanned = BTreeMap::<String, (String, BTreeMap<String, String>)>::new();
        let mut new_scanned = BTreeMap::<String, ScannedGroup>::new();
        let started = std::time::Instant::now();
        let sample = || {
            [
                crate::GWT_PROBE_LIVE.load(ProbeOrdering::Relaxed),
                crate::GWT_PROBE_PEAK.load(ProbeOrdering::Relaxed),
                crate::GWT_PROBE_TOTAL.load(ProbeOrdering::Relaxed),
                started.elapsed().as_millis() as u64,
            ]
        };
        crate::GWT_PROBE_PEAK.store(
            crate::GWT_PROBE_LIVE.load(ProbeOrdering::Relaxed),
            ProbeOrdering::Relaxed,
        );
        let before_scan = sample();

        for group in &groups {
            let snapshot = store
                .group(group)
                .and_then(|entry| entry.snapshot.clone())
                .unwrap_or_default();
            let discovered = store
                .group_sources(group)
                .ok_or_else(|| "a copied source group is unreadable".to_string())?
                .clone();
            scanned_source_count += discovered.len();
            if mode == "old" {
                // Old ScannedGroup owns the cloned map and store.loaded keeps
                // the independently decoded map through the end of the pass.
                old_scanned.insert(group.clone(), (snapshot, discovered));
            } else {
                let additions = group_additions(&mut store, group, &discovered)
                    .ok_or_else(|| "same-input group comparison unexpectedly failed".to_string())?;
                if !additions.is_empty() {
                    return Err("same-input group comparison found additions".into());
                }
                new_scanned.insert(
                    group.clone(),
                    ScannedGroup {
                        snapshot,
                        discovered: SourceSetFingerprint::capture(&discovered),
                    },
                );
            }
        }
        let after_scan = sample();

        if mode == "old" {
            for (group, (scanned_snapshot, discovered)) in &old_scanned {
                // Metadata-only slice of the original record_scanned_groups:
                // clone the held map twice even when intake added nothing.
                let previous = store
                    .group_sources(group)
                    .ok_or_else(|| "a copied source group is unreadable".to_string())?
                    .clone();
                let sources = previous.clone();
                let snapshot = (sources == *discovered).then(|| scanned_snapshot.clone());
                if store.group(group).is_none() && sources.is_empty() && snapshot.is_none() {
                    continue;
                }
                if store.group(group).is_none() || sources != previous {
                    store.set_group(group, snapshot, sources);
                } else {
                    store.set_group_snapshot(group, snapshot);
                }
            }
        } else {
            record_scanned_groups(&mut store, &new_scanned, &[]);
        }
        let after_final = sample();
        drop(old_scanned);
        drop(new_scanned);
        drop(store);
        drop(groups);
        let after_drop = sample();

        // Format only after every sample, so JSON/stdout allocations cannot
        // contaminate the following phase's allocation counters.
        let phases = [
            ("before_scan", before_scan),
            ("after_scan", after_scan),
            ("after_final", after_final),
            ("after_drop", after_drop),
        ]
        .map(|(phase, [live, peak, total, elapsed])| {
            serde_json::json!({
                "phase": phase,
                "live_bytes": live,
                "peak_bytes": peak,
                "total_allocated_bytes": total,
                "elapsed_ms": elapsed,
            })
        });
        Ok(serde_json::json!({
            "mode": mode,
            "scope": "metadata-only all-group revalidation; no payload intake, projection fold, save, or GUI",
            "state_source": "read-only grouped intake copy under target",
            "group_count": group_count,
            "indexed_source_count": indexed_source_count,
            "scanned_source_count": scanned_source_count,
            "phases": phases,
        }))
    })();
    match result {
        Ok(result) => println!("{result}"),
        Err(error) => println!("{}", serde_json::json!({ "error": error, "mode": mode })),
    }
    true
}
