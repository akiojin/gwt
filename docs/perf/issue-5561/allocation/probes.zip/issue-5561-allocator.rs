use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicU64, Ordering};
static GWT_PROBE_LIVE: AtomicU64 = AtomicU64::new(0);
static GWT_PROBE_PEAK: AtomicU64 = AtomicU64::new(0);
static GWT_PROBE_TOTAL: AtomicU64 = AtomicU64::new(0);
struct GwtMemoryProbe;
#[global_allocator]
static GWT_MEMORY_PROBE: GwtMemoryProbe = GwtMemoryProbe;
fn gwt_probe_add(size: usize) {
    let live = GWT_PROBE_LIVE.fetch_add(size as u64, Ordering::Relaxed) + size as u64;
    GWT_PROBE_PEAK.fetch_max(live, Ordering::Relaxed);
    GWT_PROBE_TOTAL.fetch_add(size as u64, Ordering::Relaxed);
}
unsafe impl GlobalAlloc for GwtMemoryProbe {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let result = unsafe { System.alloc(layout) };
        if !result.is_null() { gwt_probe_add(layout.size()); }
        result
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let result = unsafe { System.alloc_zeroed(layout) };
        if !result.is_null() { gwt_probe_add(layout.size()); }
        result
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        GWT_PROBE_LIVE.fetch_sub(layout.size() as u64, Ordering::Relaxed);
        unsafe { System.dealloc(ptr, layout) };
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let result = unsafe { System.realloc(ptr, layout, size) };
        if !result.is_null() {
            GWT_PROBE_LIVE.fetch_sub(layout.size() as u64, Ordering::Relaxed);
            gwt_probe_add(size);
        }
        result
    }
}
fn gwt_memory_probe_start() {
    let Ok(path) = std::env::var("GWT_MEMORY_ALLOCATOR_PROBE") else { return; };
    std::thread::spawn(move || {
        use std::io::Write as _;
        let mut file = std::fs::OpenOptions::new().create(true).append(true).open(path).unwrap();
        loop {
            let live = GWT_PROBE_LIVE.load(Ordering::Relaxed);
            let peak = GWT_PROBE_PEAK.load(Ordering::Relaxed);
            let total = GWT_PROBE_TOTAL.load(Ordering::Relaxed);
            writeln!(file, "{{\"timestamp\":\"{}\",\"live_bytes\":{},\"peak_bytes\":{},\"cumulative_allocated_bytes\":{}}}", chrono::Utc::now().to_rfc3339(), live, peak, total).unwrap();
            file.flush().unwrap();
            std::thread::sleep(std::time::Duration::from_secs(5));
        }
    });
}
