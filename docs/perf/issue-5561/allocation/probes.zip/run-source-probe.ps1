$ErrorActionPreference='Stop'
$checkout=(Get-Location).Path
$binary=Join-Path $checkout 'target/debug/gwt.exe'
$index=Join-Path $checkout 'target/issue-5561/intake-copy/index.json'
$indexHash=(Get-FileHash -LiteralPath $index).Hash
$results=@{}
foreach($mode in @('old','new')) {
  $start=[Diagnostics.ProcessStartInfo]::new($binary)
  $start.UseShellExecute=$false
  $start.CreateNoWindow=$true
  $start.WindowStyle=[Diagnostics.ProcessWindowStyle]::Hidden
  $start.WorkingDirectory=$checkout
  $start.Environment['GWT_MEMORY_SOURCE_PROBE_MODE']=$mode
  $start.Environment['GWT_MEMORY_SOURCE_PROBE_STATE']=Join-Path $checkout 'target/issue-5561/intake-copy.json'
  [void]$start.Environment.Remove('GWT_MEMORY_ALLOCATOR_PROBE')
  $start.RedirectStandardOutput=$true
  $start.RedirectStandardError=$true
  $start.StandardOutputEncoding=[Text.UTF8Encoding]::new($false)
  $process=[Diagnostics.Process]::Start($start)
  $stdout=$process.StandardOutput.ReadToEndAsync()
  $stderr=$process.StandardError.ReadToEndAsync()
  $timer=[Diagnostics.Stopwatch]::StartNew()
  $peakRss=0L
  try {
    while(-not $process.WaitForExit(100)) {
      $process.Refresh()
      $peakRss=[Math]::Max($peakRss,$process.WorkingSet64)
      if($timer.Elapsed.TotalSeconds -gt 600){$process.Kill($true);throw 'Probe timeout'}
    }
    $text=$stdout.GetAwaiter().GetResult()
    if($process.ExitCode -ne 0){throw ($stderr.GetAwaiter().GetResult())}
    $result=$text|ConvertFrom-Json
    if($result.PSObject.Properties.Name -contains 'error'){throw $result.error}
    $result|Add-Member -NotePropertyName gui_surface -NotePropertyValue $false
    $result|Add-Member -NotePropertyName process_peak_rss_sampled_bytes -NotePropertyValue $peakRss
    $result|Add-Member -NotePropertyName process_id -NotePropertyValue $process.Id
    $result|ConvertTo-Json -Depth 7|Set-Content -LiteralPath "target/issue-5561/allocation-$mode.json" -Encoding utf8
    $results[$mode]=$result
    Write-Output ($result|ConvertTo-Json -Depth 7 -Compress)
  } finally {$process.Dispose()}
}
if($results.old.scanned_source_count -ne $results.new.scanned_source_count){throw 'Input source count differs'}
if((Get-FileHash -LiteralPath $index).Hash -ne $indexHash){throw 'Diagnostic copy changed'}
@{index_sha256=$indexHash.ToLowerInvariant();binary_sha256=(Get-FileHash -LiteralPath $binary).Hash.ToLowerInvariant();allocator_sha256=(Get-FileHash -LiteralPath target/issue-5561-allocator.rs).Hash.ToLowerInvariant();probe_sha256=(Get-FileHash -LiteralPath target/issue-5561-source-probe.rs).Hash.ToLowerInvariant();observed_at=[DateTime]::UtcNow.ToString('o');same_input=$true;separate_processes=$true}|ConvertTo-Json|Set-Content -LiteralPath target/issue-5561/allocation-metadata.json -Encoding utf8
