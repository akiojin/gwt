#![allow(dead_code)]
use std::{alloc::{GlobalAlloc, Layout, System}, collections::HashMap, path::PathBuf, sync::{Arc, atomic::{AtomicU64, Ordering}}};
static LIVE: AtomicU64 = AtomicU64::new(0);
static PEAK: AtomicU64 = AtomicU64::new(0);
struct Probe;
#[global_allocator]
static ALLOCATOR: Probe = Probe;
fn add(n: usize) { let live = LIVE.fetch_add(n as u64, Ordering::Relaxed) + n as u64; PEAK.fetch_max(live, Ordering::Relaxed); }
unsafe impl GlobalAlloc for Probe {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 { let p=unsafe { System.alloc(layout) }; if !p.is_null(){add(layout.size());} p }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 { let p=unsafe { System.alloc_zeroed(layout) }; if !p.is_null(){add(layout.size());} p }
    unsafe fn dealloc(&self, p: *mut u8, layout: Layout) { LIVE.fetch_sub(layout.size() as u64, Ordering::Relaxed); unsafe {System.dealloc(p,layout)} }
    unsafe fn realloc(&self, p: *mut u8, layout: Layout, n: usize) -> *mut u8 { let p=unsafe{System.realloc(p,layout,n)}; if !p.is_null(){LIVE.fetch_sub(layout.size() as u64,Ordering::Relaxed);add(n);} p }
}
fn capture(phase: &str) { let live=LIVE.load(Ordering::Relaxed);let peak=PEAK.load(Ordering::Relaxed); println!("{{\"phase\":\"{phase}\",\"live_bytes\":{live},\"peak_bytes\":{peak}}}"); }
mod gwt_core { pub type Result<T> = std::io::Result<T>; }
mod gwt { pub mod worktree_inventory { pub struct WorktreeEntry; } }
#[derive(Debug)]
struct WorkspaceExecutionContainerRef;
struct SharedWorkEventsSource { content: Arc<str>, container: Option<Arc<WorkspaceExecutionContainerRef>> }
impl SharedWorkEventsSource { fn with_shared_container(content: Arc<str>, container: Option<Arc<WorkspaceExecutionContainerRef>>) -> Self {Self{content,container}} }
#[derive(Debug)]
struct PendingWorkEventsSource { key: String, fingerprint: String, content: Arc<str>, container: Option<Arc<WorkspaceExecutionContainerRef>>, reload_from_worktree: bool }
type SourceFingerprints=Vec<(String,String)>;
type ReloadedWorkEventsSources=(Vec<SharedWorkEventsSource>,SourceFingerprints);
struct LocalSource { metadata: (), container: Option<Arc<WorkspaceExecutionContainerRef>>, events_path: PathBuf, kind: () }
impl LocalSource {fn key(&self)->String {unreachable!()}}
struct Group { sources: Vec<(LocalSource,())> }
fn worktree_group_scans(_: &[gwt::worktree_inventory::WorktreeEntry]) -> std::iter::Empty<gwt_core::Result<Group>> { std::iter::empty() }
fn source_fingerprint(_: &(), _: Option<&WorkspaceExecutionContainerRef>) -> String {unreachable!()}
fn read_shared_work_event_source(_: &PathBuf, _: (), _: &mut HashMap<String,Arc<str>>) -> gwt_core::Result<Arc<str>> {unreachable!()}
// All synthetic reference inputs share the same validated payload, hence the
// same 64-byte digest. Hash computation cost is outside this allocation slice.
fn content_fingerprint(_: &str)->String {"a".repeat(64)}

fn load_pending_sources_for_rebuild(
    pending_sources: Vec<PendingWorkEventsSource>,
    worktree_entries: &[gwt::worktree_inventory::WorktreeEntry],
) -> gwt_core::Result<ReloadedWorkEventsSources> {
    let mut contents = Vec::with_capacity(pending_sources.len());
    let mut fingerprints = Vec::with_capacity(pending_sources.len());
    let mut prelock_reads = HashMap::new();
    let mut shared_content = HashMap::new();
    for source in pending_sources {
        // Reserve by distinct payloads, not the many source aliases in a fleet.
        shared_content
            .entry(content_fingerprint(&source.content))
            .or_insert_with(|| Arc::clone(&source.content));
        if source.reload_from_worktree {
            prelock_reads.insert(source.key, (source.fingerprint, source.content));
            continue;
        }
        contents.push(SharedWorkEventsSource::with_shared_container(
            source.content,
            source.container,
        ));
        fingerprints.push((source.key, source.fingerprint));
    }

    // Issue #5208: reuse the discovery pass's validated content whenever the
    // lock-free re-scan observes the same
    // key and size/mtime/container fingerprint — the same identity the
    // incremental poll already trusts — and read only new or changed sources.
    // Re-scan the already enumerated worktree roots after the authoritative
    // snapshot is captured. This catches an immutable shard published between
    // the initial source scan and intake without paying for a second
    // `git worktree list` process.
    for group in worktree_group_scans(worktree_entries) {
        for (source, _) in group?.sources {
            // The scan took metadata before this content read: a write racing
            // the read leaves the older fingerprint behind, so the next pass
            // reads the source again.
            let fingerprint = source_fingerprint(&source.metadata, source.container.as_deref());
            let key = source.key();
            let cached = prelock_reads
                .remove(&key)
                .filter(|(previous, _)| previous == &fingerprint)
                .map(|(_, content)| content);
            let content = match cached {
                Some(content) => content,
                None => read_shared_work_event_source(
                    &source.events_path,
                    source.kind,
                    &mut shared_content,
                )?,
            };
            fingerprints.push((key, fingerprint));
            contents.push(SharedWorkEventsSource::with_shared_container(
                content,
                source.container,
            ));
        }
    }
    println!("{{\"cache_entries\":{},\"cache_capacity\":{}}}", shared_content.len(), shared_content.capacity());
    capture("loader_before_return");
    Ok((contents, fingerprints))
}
fn run_loader(p: Vec<PendingWorkEventsSource>)->gwt_core::Result<ReloadedWorkEventsSources>{load_pending_sources_for_rebuild(p,&[])}

fn main() {
    let count=200_000usize;
    let content: Arc<str>=Arc::from("one shared validated reference payload");
    let pending=(0..count).map(|i|PendingWorkEventsSource {
        key: format!("ref:origin/fixture-{i:08}:.gwt/work/events/ab/{}.jsonl", "b".repeat(64)),
        fingerprint:"c".repeat(64),content:Arc::clone(&content),container:None,reload_from_worktree:false,
    }).collect::<Vec<_>>();
    capture("input_ready");
    let loaded=run_loader(pending).unwrap();
    assert_eq!(loaded.0.len(),count);assert_eq!(loaded.1.len(),count);
    capture("returned");
    drop(loaded);drop(content);
    capture("all_inputs_released");
}
