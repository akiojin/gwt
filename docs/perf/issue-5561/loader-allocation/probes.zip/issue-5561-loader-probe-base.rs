#![allow(dead_code)]
use std::{alloc::{GlobalAlloc, Layout, System}, collections::HashMap, path::PathBuf, sync::{Arc, atomic::{AtomicU64, Ordering}}};
static LIVE: AtomicU64 = AtomicU64::new(0);
static PEAK: AtomicU64 = AtomicU64::new(0);
struct Probe;
#[global_allocator]
static ALLOCATOR: Probe = Probe;
fn add(n: usize) { let live = LIVE.fetch_add(n as u64, Ordering::Relaxed) + n as u64; PEAK.fetch_max(live, Ordering::Relaxed); }
unsafe impl GlobalAlloc for Probe {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 { let p=unsafe { System.alloc(layout) }; if !p.is_null(){add(layout.size());} p }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 { let p=unsafe { System.alloc_zeroed(layout) }; if !p.is_null(){add(layout.size());} p }
    unsafe fn dealloc(&self, p: *mut u8, layout: Layout) { LIVE.fetch_sub(layout.size() as u64, Ordering::Relaxed); unsafe {System.dealloc(p,layout)} }
    unsafe fn realloc(&self, p: *mut u8, layout: Layout, n: usize) -> *mut u8 { let p=unsafe{System.realloc(p,layout,n)}; if !p.is_null(){LIVE.fetch_sub(layout.size() as u64,Ordering::Relaxed);add(n);} p }
}
fn capture(phase: &str) { let live=LIVE.load(Ordering::Relaxed);let peak=PEAK.load(Ordering::Relaxed); println!("{{\"phase\":\"{phase}\",\"live_bytes\":{live},\"peak_bytes\":{peak}}}"); }
mod gwt_core { pub type Result<T> = std::io::Result<T>; }
mod gwt { pub mod worktree_inventory { pub struct WorktreeEntry; } }
#[derive(Debug)]
struct WorkspaceExecutionContainerRef;
struct SharedWorkEventsSource { content: Arc<str>, container: Option<Arc<WorkspaceExecutionContainerRef>> }
impl SharedWorkEventsSource { fn with_shared_container(content: Arc<str>, container: Option<Arc<WorkspaceExecutionContainerRef>>) -> Self {Self{content,container}} }
#[derive(Debug)]
struct PendingWorkEventsSource { key: String, fingerprint: String, content: Arc<str>, container: Option<Arc<WorkspaceExecutionContainerRef>>, reload_from_worktree: bool }
type SourceFingerprints=Vec<(String,String)>;
type ReloadedWorkEventsSources=(Vec<SharedWorkEventsSource>,SourceFingerprints);
struct LocalSource { metadata: (), container: Option<Arc<WorkspaceExecutionContainerRef>>, events_path: PathBuf, kind: () }
impl LocalSource {fn key(&self)->String {unreachable!()}}
struct Group { sources: Vec<(LocalSource,())> }
fn worktree_group_scans(_: &[gwt::worktree_inventory::WorktreeEntry]) -> std::iter::Empty<gwt_core::Result<Group>> { std::iter::empty() }
fn source_fingerprint(_: &(), _: Option<&WorkspaceExecutionContainerRef>) -> String {unreachable!()}
fn read_shared_work_event_source(_: &PathBuf, _: (), _: &mut HashMap<String,Arc<str>>) -> gwt_core::Result<Arc<str>> {unreachable!()}
// All synthetic reference inputs share the same validated payload, hence the
// same 64-byte digest. Hash computation cost is outside this allocation slice.
fn content_fingerprint(_: &str)->String {"a".repeat(64)}

// LOADER

fn main() {
    let count=200_000usize;
    let content: Arc<str>=Arc::from("one shared validated reference payload");
    let pending=(0..count).map(|i|PendingWorkEventsSource {
        key: format!("ref:origin/fixture-{i:08}:.gwt/work/events/ab/{}.jsonl", "b".repeat(64)),
        fingerprint:"c".repeat(64),content:Arc::clone(&content),container:None,reload_from_worktree:false,
    }).collect::<Vec<_>>();
    capture("input_ready");
    let loaded=run_loader(pending).unwrap();
    assert_eq!(loaded.0.len(),count);assert_eq!(loaded.1.len(),count);
    capture("returned");
    drop(loaded);drop(content);
    capture("all_inputs_released");
}
