use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::{Arc,atomic::{AtomicUsize,Ordering}};
use std::collections::HashMap;
use gwt_core::workspace_projection::{WorkEvent,WorkEventKind,DecodedWorkspaceWorkEvent,WorkspaceExecutionContainerRef,decode_workspace_work_event_line};
use gwt_core::error::{GwtError,Result};
struct Counter;
static LIVE: AtomicUsize=AtomicUsize::new(0);
static PEAK: AtomicUsize=AtomicUsize::new(0);
static CUM: AtomicUsize=AtomicUsize::new(0);
static CLONES: AtomicUsize=AtomicUsize::new(0);
static SERIALIZES: AtomicUsize=AtomicUsize::new(0);
static DECODES: AtomicUsize=AtomicUsize::new(0);
static PHASE_LIVE: AtomicUsize=AtomicUsize::new(0);
unsafe impl GlobalAlloc for Counter {
 unsafe fn alloc(&self,l:Layout)->*mut u8 { let p=unsafe{System.alloc(l)};if !p.is_null(){let n=LIVE.fetch_add(l.size(),Ordering::Relaxed)+l.size();PEAK.fetch_max(n,Ordering::Relaxed);CUM.fetch_add(l.size(),Ordering::Relaxed);}p }
 unsafe fn dealloc(&self,p:*mut u8,l:Layout){unsafe{System.dealloc(p,l)};LIVE.fetch_sub(l.size(),Ordering::Relaxed);}
 unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {let q=unsafe{System.realloc(p,l,n)};if !q.is_null(){let now=if n>=l.size(){LIVE.fetch_add(n-l.size(),Ordering::Relaxed)+n-l.size()}else{LIVE.fetch_sub(l.size()-n,Ordering::Relaxed)-(l.size()-n)};PEAK.fetch_max(now,Ordering::Relaxed);CUM.fetch_add(n,Ordering::Relaxed);}q}
}
#[global_allocator] static ALLOC:Counter=Counter;
fn capture(){PHASE_LIVE.store(LIVE.load(Ordering::Relaxed),Ordering::Relaxed);}
#[derive(Default,Debug,PartialEq,Eq)] struct WorkEventsIntakeReport{skipped_opaque:usize,skipped_invalid:usize,skipped_close_kind:usize,skipped_duplicate:usize}
#[derive(Debug,Clone)] struct SharedWorkEventsSource{content:Arc<str>,source_execution_container:Option<Arc<WorkspaceExecutionContainerRef>>}
#[derive(Debug,Clone)] enum CachedSharedWorkEventLine{Known(Box<WorkEvent>),Opaque,Invalid(String)}
fn is_close_kind(event:&WorkEvent)->bool {matches!(event.kind,WorkEventKind::Pause|WorkEventKind::Done|WorkEventKind::Discard)}
fn old<F>(
    sources: impl IntoIterator<Item = SharedWorkEventsSource>,
    report: &mut WorkEventsIntakeReport,
    mut decode: F,
) -> Result<Vec<(WorkEvent, String)>>
where
    F: FnMut(&[u8]) -> Result<DecodedWorkspaceWorkEvent>,
{
    let mut incoming = Vec::new();
    let mut decoded_by_content_identity = HashMap::<usize, Vec<CachedSharedWorkEventLine>>::new();
    // Issue #4371: one shard is offered once per origin ref that holds it
    // (701 refs peaked the rebuild at 4.7 GB). The fold keeps the canonical
    // event, and the first identical duplicate records its provenance; any
    // further identical copy is a no-op it would only count as a duplicate.
    let mut copies_by_stable_key = HashMap::<String, u8>::new();
    for source in sources {
        let content_identity = Arc::as_ptr(&source.content) as *const () as usize;
        let decoded = decoded_by_content_identity
            .entry(content_identity)
            .or_insert_with(|| {
                source
                    .content
                    .lines()
                    .filter_map(|line| {
                        let line = line.trim();
                        if line.is_empty() {
                            return None;
                        }
                        Some(match decode(line.as_bytes()) {
                            Ok(DecodedWorkspaceWorkEvent::Known(event)) => {
                                if event.execution_container.is_none() && !is_close_kind(&event) {
                                    tracing::warn!(
                                        event_id = %event.id,
                                        work_item_id = %event.work_item_id,
                                        source = ?source.source_execution_container,
                                        "work events intake: event has no explicit container; retaining history without a Work ref"
                                    );
                                }
                                CachedSharedWorkEventLine::Known(event)
                            }
                            Ok(DecodedWorkspaceWorkEvent::Opaque) => {
                                CachedSharedWorkEventLine::Opaque
                            }
                            Err(error) => CachedSharedWorkEventLine::Invalid(error.to_string()),
                        })
                    })
                    .collect()
            });
        for cached in decoded.iter() {
            let event = match cached {
                CachedSharedWorkEventLine::Known(event) => { CLONES.fetch_add(1, Ordering::Relaxed); event.as_ref().clone() },
                CachedSharedWorkEventLine::Opaque => {
                    report.skipped_opaque += 1;
                    continue;
                }
                CachedSharedWorkEventLine::Invalid(error) => {
                    report.skipped_invalid += 1;
                    tracing::warn!(%error, "work events intake: skipping malformed line");
                    continue;
                }
            };
            if is_close_kind(&event) {
                report.skipped_close_kind += 1;
                continue;
            }
            SERIALIZES.fetch_add(1, Ordering::Relaxed);
            let stable_key = serde_json::to_string(&event).map_err(|error| {
                GwtError::Other(format!("work events intake stable key: {error}"))
            })?;
            let copies = copies_by_stable_key.entry(stable_key.clone()).or_default();
            if *copies >= 2 {
                report.skipped_duplicate += 1;
                continue;
            }
            *copies += 1;
            incoming.push((event, stable_key));
        }
    }
    capture();
    Ok(incoming)
}
fn grouped<F>(
    sources: impl IntoIterator<Item = SharedWorkEventsSource>,
    report: &mut WorkEventsIntakeReport,
    mut decode: F,
) -> Result<Vec<(WorkEvent, String)>>
where
    F: FnMut(&[u8]) -> Result<DecodedWorkspaceWorkEvent>,
{
    // A shard can be offered by hundreds of refs. Keep one raw source and
    // its multiplicity instead of retaining every decoded event in a cache.
    // Retaining the Arc also keeps its pointer identity valid while grouping.
    let mut grouped = Vec::<(SharedWorkEventsSource, usize)>::new();
    let mut group_by_identity = HashMap::<usize, usize>::new();
    for source in sources {
        let identity = Arc::as_ptr(&source.content) as *const () as usize;
        if let Some(&index) = group_by_identity.get(&identity) {
            grouped[index].1 += 1;
        } else {
            group_by_identity.insert(identity, grouped.len());
            grouped.push((source, 1));
        }
    }
    drop(group_by_identity);

    let mut incoming = Vec::new();
    // Issue #4371: one shard is offered once per origin ref that holds it
    // (701 refs peaked the rebuild at 4.7 GB). The fold keeps the canonical
    // event, and the first identical duplicate records its provenance; any
    // further identical copy is a no-op it would only count as a duplicate.
    let mut copies_by_stable_key = HashMap::<String, u8>::new();
    for (source, multiplicity) in grouped {
        for line in source
            .content
            .lines()
            .map(str::trim)
            .filter(|line| !line.is_empty())
        {
            let event = match decode(line.as_bytes()) {
                Ok(DecodedWorkspaceWorkEvent::Known(event)) => *event,
                Ok(DecodedWorkspaceWorkEvent::Opaque) => {
                    report.skipped_opaque += multiplicity;
                    continue;
                }
                Err(error) => {
                    report.skipped_invalid += multiplicity;
                    tracing::warn!(%error, multiplicity, "work events intake: skipping malformed line");
                    continue;
                }
            };
            if is_close_kind(&event) {
                report.skipped_close_kind += multiplicity;
                continue;
            }
            if event.execution_container.is_none() {
                tracing::warn!(
                    event_id = %event.id,
                    work_item_id = %event.work_item_id,
                    source = ?source.source_execution_container,
                    "work events intake: event has no explicit container; retaining history without a Work ref"
                );
            }
            SERIALIZES.fetch_add(1, Ordering::Relaxed);
            let stable_key = serde_json::to_string(&event).map_err(|error| {
                GwtError::Other(format!("work events intake stable key: {error}"))
            })?;
            let copies = copies_by_stable_key.get(&stable_key).copied().unwrap_or(0);
            let accepted = multiplicity.min(usize::from(2 - copies));
            report.skipped_duplicate += multiplicity - accepted;
            if accepted == 0 {
                continue;
            }
            copies_by_stable_key.insert(stable_key.clone(), copies + accepted as u8);
            if accepted == 2 {
                CLONES.fetch_add(1, Ordering::Relaxed);
                incoming.push((event.clone(), stable_key.clone()));
            }
            incoming.push((event, stable_key));
        }
    }
    capture();
    Ok(incoming)
}

fn accumulator<F>(sources:impl IntoIterator<Item=SharedWorkEventsSource>,report:&mut WorkEventsIntakeReport,mut decode:F)->Result<Vec<(WorkEvent,String)>> where F:FnMut(&[u8])->Result<DecodedWorkspaceWorkEvent>{
 let mut groups=Vec::<(SharedWorkEventsSource,usize)>::new();
 let mut identity_to_group=HashMap::<usize,usize>::new();
 for source in sources {let identity=Arc::as_ptr(&source.content) as *const () as usize; if let Some(index)=identity_to_group.get(&identity){groups[*index].1+=1;}else{identity_to_group.insert(identity,groups.len());groups.push((source,1));}}
 drop(identity_to_group);
 let mut accepted=HashMap::<String,(WorkEvent,usize)>::new();
 for (source,multiplicity) in groups {
  for line in source.content.lines().map(str::trim).filter(|line|!line.is_empty()) {
   let event=match decode(line.as_bytes()) {Ok(DecodedWorkspaceWorkEvent::Known(event))=>*event,Ok(DecodedWorkspaceWorkEvent::Opaque)=>{report.skipped_opaque+=multiplicity;continue;},Err(_)=>{report.skipped_invalid+=multiplicity;continue;}};
   if is_close_kind(&event){report.skipped_close_kind+=multiplicity;continue;}
   SERIALIZES.fetch_add(1,Ordering::Relaxed);
   let stable_key=serde_json::to_string(&event).map_err(|e|GwtError::Other(e.to_string()))?;
   match accepted.entry(stable_key) {
    std::collections::hash_map::Entry::Vacant(entry)=>{let keep=multiplicity.min(2);report.skipped_duplicate+=multiplicity-keep;entry.insert((event,keep));},
    std::collections::hash_map::Entry::Occupied(mut entry)=>{let (_,copies)=entry.get_mut();let keep=multiplicity.min(2-*copies);report.skipped_duplicate+=multiplicity-keep;*copies+=keep;}
   }
  }
 }
 let mut incoming=Vec::with_capacity(accepted.values().map(|(_,copies)|copies).sum());
 for (key,(event,copies)) in accepted {if copies==2 {CLONES.fetch_add(1,Ordering::Relaxed);incoming.push((event.clone(),key.clone()));}incoming.push((event,key));}
 capture();
 Ok(incoming)
}
fn main(){
 let args:Vec<String>=std::env::args().collect();let mode=&args[1];let unique:usize=args[2].parse().unwrap();let lines:usize=args[3].parse().unwrap();let aliases:usize=args[4].parse().unwrap();let title_len:usize=args[5].parse().unwrap();
 let mut sources=Vec::new();let payload="x".repeat(title_len);
 for group in 0..unique {let mut raw=String::new();for line in 0..lines{raw.push_str(&format!("{{\"id\":\"evt-{group}-{line}\",\"work_item_id\":\"work-{group}\",\"kind\":\"start\",\"updated_at\":\"2026-07-28T10:00:00Z\",\"title\":\"{payload}\",\"execution_container\":{{\"branch\":\"work/probe\"}}}}\n"));}let content:Arc<str>=Arc::from(raw);for _ in 0..aliases{sources.push(SharedWorkEventsSource{content:Arc::clone(&content),source_execution_container:None});}}
 let input_live=LIVE.load(Ordering::Relaxed);CUM.store(0,Ordering::Relaxed);PEAK.store(input_live,Ordering::Relaxed);
 let mut report=WorkEventsIntakeReport::default();let started=std::time::Instant::now();
 let decode=|line:&[u8]|{DECODES.fetch_add(1,Ordering::Relaxed);decode_workspace_work_event_line(line)};
 let incoming=if mode=="old"{old(sources,&mut report,decode)}else if mode=="accumulator"{accumulator(sources,&mut report,decode)}else{grouped(sources,&mut report,decode)}.unwrap();
 let elapsed=started.elapsed().as_secs_f64();let live=LIVE.load(Ordering::Relaxed);let peak=PEAK.load(Ordering::Relaxed);let cum=CUM.load(Ordering::Relaxed);let before_return=PHASE_LIVE.load(Ordering::Relaxed);
 let key_bytes:usize=incoming.iter().map(|(_,key)|key.len()).sum();
 let mut keys=incoming.iter().map(|(_,key)|key.as_str()).collect::<Vec<_>>();keys.sort();let mut digest=14695981039346656037u64;for key in keys{for byte in key.bytes().chain([0]){digest^=u64::from(byte);digest=digest.wrapping_mul(1099511628211);}}
 println!("{{\"mode\":\"{}\",\"unique_contents\":{},\"lines_per_content\":{},\"aliases\":{},\"title_bytes\":{},\"source_count\":{},\"event_type_bytes\":{},\"input_live_bytes\":{},\"before_return_live_bytes\":{},\"returned_live_bytes\":{},\"peak_live_bytes\":{},\"cumulative_allocated_bytes\":{},\"decode_count\":{},\"serialize_count\":{},\"clone_count\":{},\"incoming_count\":{},\"skipped_duplicate\":{},\"output_key_bytes\":{},\"output_digest\":{},\"seconds\":{}}}",mode,unique,lines,aliases,title_len,unique*aliases,std::mem::size_of::<WorkEvent>(),input_live,before_return,live,peak,cum,DECODES.load(Ordering::Relaxed),SERIALIZES.load(Ordering::Relaxed),CLONES.load(Ordering::Relaxed),incoming.len(),report.skipped_duplicate,key_bytes,digest,elapsed);
}
