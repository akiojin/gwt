[CmdletBinding()]
param([switch]$SkipBuild)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$taskCheckout = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
Push-Location -LiteralPath $taskCheckout
try {
  $taskDeps = @(
    'target/debug/deps/libgwt_core-0df1c2168f9284e5.rlib',
    'target/debug/deps/libserde_json-3085a25fd445b373.rlib',
    'target/debug/deps/libtracing-e49ed03754391b73.rlib'
  )
  foreach ($taskDep in $taskDeps) {
    if (!(Test-Path -LiteralPath $taskDep)) { throw "Missing original dependency: $taskDep. Restore the measured artifacts; do not silently select another serde/tracing build." }
  }
  $taskProfile = [Environment]::GetFolderPath('UserProfile')
  $taskNativePaths = @(Get-ChildItem "$taskProfile/.cargo/registry/src/*/windows_x86_64_msvc-*/lib" -Directory | Select-Object -ExpandProperty FullName)
  $taskNativePaths += @(Get-ChildItem target/debug/build -Directory | ForEach-Object {
    $taskNativeOut = Join-Path $_.FullName 'out'
    if (Test-Path -LiteralPath $taskNativeOut) {
      if (Get-ChildItem -LiteralPath $taskNativeOut -Filter '*.lib' -File | Select-Object -First 1) { $taskNativeOut }
    }
  })
  $taskRustcArgs = @(
    '--edition=2021', 'target/issue-5561-current/collector-product-probe.rs',
    '-L', 'dependency=target/debug/deps',
    '--extern', "gwt_core=$($taskDeps[0])",
    '--extern', "serde_json=$($taskDeps[1])",
    '--extern', "tracing=$($taskDeps[2])"
  )
  foreach ($taskNativePath in $taskNativePaths) { $taskRustcArgs += @('-L', "native=$taskNativePath") }
  $taskRustcArgs += @('-o', 'target/issue-5561-current/collector-product.exe')
  [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'collector-product-build-arguments.json'), (ConvertTo-Json -InputObject $taskRustcArgs -Depth 4))
  if (!$SkipBuild) {
    & rustc @taskRustcArgs
    if ($LASTEXITCODE -ne 0) { throw "rustc failed: $LASTEXITCODE" }
  }
  # Python preserves the complete unsigned 64-bit digest without float conversion.
  @'
from pathlib import Path
import subprocess,json,hashlib,datetime
root=Path('target/issue-5561-current')
records=[]
for fixture in [(64,4,701,1024),(2000,4,8,2048)]:
    rows=[]
    for mode in ['old','grouped']:
        command=[str(root/'collector-product.exe'),mode,*map(str,fixture)]
        record=json.loads(subprocess.check_output(command,encoding='utf-8'))
        record['command']=command
        rows.append(record)
        records.append(record)
        print(json.dumps(record),flush=True)
    unique,lines,aliases,title_bytes=fixture
    assert all(r['incoming_count']==unique*lines*min(aliases,2) for r in rows)
    assert all(r['skipped_duplicate']==unique*lines*max(aliases-2,0) for r in rows)
    assert all(r['decode_count']==unique*lines for r in rows)
    assert len({r['output_digest'] for r in rows})==1
    assert len({r['output_key_bytes'] for r in rows})==1
    assert len({(r['unique_contents'],r['lines_per_content'],r['aliases'],r['title_bytes'],r['source_count']) for r in rows})==1
metadata={
    'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'product_function_extraction':json.loads((root/'collector-product-source.json').read_text(encoding='utf-8')),
    'equivalence_assertions':'PASS: same deterministic input dimensions, sorted full-key digest, full-key byte count, expected incoming/skipped duplicate counts, and decode count for old and exact product candidate in both fixtures',
    'source_sha256':hashlib.sha256((root/'collector-product-probe.rs').read_bytes()).hexdigest(),
    'binary_sha256':hashlib.sha256((root/'collector-product.exe').read_bytes()).hexdigest(),
    'linked_dependencies_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path('target/debug/deps/libgwt_core-0df1c2168f9284e5.rlib'),Path('target/debug/deps/libserde_json-3085a25fd445b373.rlib'),Path('target/debug/deps/libtracing-e49ed03754391b73.rlib')]},
    'rustc_build_arguments_file':str(root/'collector-product-build-arguments.json'),
    'scope':'Exact candidate extraction; see collector-product-source.json and collector-reproduce.md. Fixed start-event synthetic collector slice only; no GUI, rescan, fold or persistence. Allocation snapshots precede output digest/JSON. Timing is descriptive only.',
    'records':records,
}
(root/'collector-product.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
print('PASS: both fixture equivalence assertions; collector-product.json saved',flush=True)
'@ | python
  if ($LASTEXITCODE -ne 0) { throw "Probe or equivalence assertion failed: $LASTEXITCODE" }
} finally { Pop-Location }
