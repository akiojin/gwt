fn collect_shared_work_event_sources_with_decoder<F>(
    sources: impl IntoIterator<Item = SharedWorkEventsSource>,
    report: &mut WorkEventsIntakeReport,
    mut decode: F,
) -> Result<Vec<(WorkEvent, String)>>
where
    F: FnMut(&[u8]) -> Result<DecodedWorkspaceWorkEvent>,
{
    let mut incoming = Vec::new();
    let mut decoded_by_content_identity = HashMap::<usize, Vec<CachedSharedWorkEventLine>>::new();
    // Issue #4371: one shard is offered once per origin ref that holds it
    // (701 refs peaked the rebuild at 4.7 GB). The fold keeps the canonical
    // event, and the first identical duplicate records its provenance; any
    // further identical copy is a no-op it would only count as a duplicate.
    let mut copies_by_stable_key = HashMap::<String, u8>::new();
    for source in sources {
        let content_identity = Arc::as_ptr(&source.content) as *const () as usize;
        let decoded = decoded_by_content_identity
            .entry(content_identity)
            .or_insert_with(|| {
                source
                    .content
                    .lines()
                    .filter_map(|line| {
                        let line = line.trim();
                        if line.is_empty() {
                            return None;
                        }
                        Some(match decode(line.as_bytes()) {
                            Ok(DecodedWorkspaceWorkEvent::Known(event)) => {
                                if event.execution_container.is_none() && !is_close_kind(&event) {
                                    tracing::warn!(
                                        event_id = %event.id,
                                        work_item_id = %event.work_item_id,
                                        source = ?source.source_execution_container,
                                        "work events intake: event has no explicit container; retaining history without a Work ref"
                                    );
                                }
                                CachedSharedWorkEventLine::Known(event)
                            }
                            Ok(DecodedWorkspaceWorkEvent::Opaque) => {
                                CachedSharedWorkEventLine::Opaque
                            }
                            Err(error) => CachedSharedWorkEventLine::Invalid(error.to_string()),
                        })
                    })
                    .collect()
            });
        for cached in decoded.iter() {
            let event = match cached {
                CachedSharedWorkEventLine::Known(event) => event.as_ref().clone(),
                CachedSharedWorkEventLine::Opaque => {
                    report.skipped_opaque += 1;
                    continue;
                }
                CachedSharedWorkEventLine::Invalid(error) => {
                    report.skipped_invalid += 1;
                    tracing::warn!(%error, "work events intake: skipping malformed line");
                    continue;
                }
            };
            if is_close_kind(&event) {
                report.skipped_close_kind += 1;
                continue;
            }
            let stable_key = serde_json::to_string(&event).map_err(|error| {
                GwtError::Other(format!("work events intake stable key: {error}"))
            })?;
            let copies = copies_by_stable_key.entry(stable_key.clone()).or_default();
            if *copies >= 2 {
                report.skipped_duplicate += 1;
                continue;
            }
            *copies += 1;
            incoming.push((event, stable_key));
        }
    }
    Ok(incoming)
}
